# Ansible Role: Kafka



## Requirements

None.

## Role Variables



## Dependencies

None.

## Example Playbook

    - hosts: all
      roles:
        - opsta.kafka


## License

MIT

## Author Information

Opsta (Thailand) Co.,Ltd.
